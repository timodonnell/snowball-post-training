"""Run only after the model response has been saved by the host harness."""
import json
import os
from pathlib import Path
from coordinate_scoring import score_response

def verify(root=Path("/tests"), answer=Path("/app/answer.txt"), output=Path("/logs/verifier")):
    output.mkdir(parents=True, exist_ok=True)
    (output / "reward.txt").write_text("0\n")
    contract = json.loads((root / "gold.json").read_text())
    raw = answer.read_text() if answer.exists() and answer.stat().st_size <= 8000000 else ""
    status_path = answer.with_name("answer_status.json")
    status = json.loads(status_path.read_text()) if status_path.exists() else {}
    outcome = score_response(raw, contract["answer_schema"], contract["gold_answer"],
        parameters=contract["parameters"], truncated=status.get("truncated", False),
        provider_refusal=status.get("provider_refusal", False))
    tool_violation = bool(status.get("tool_events", []))
    reward = float(outcome["score"].get("correct", False) and not tool_violation)
    details = {"reward": reward, "partial_credit": outcome["score"]["score"],
               "tool_violation": tool_violation, "outcome": outcome}
    (output / "details.json").write_text(json.dumps(details, indent=2))
    (output / "reward.txt").write_text(str(reward) + "\n")
    return details

if __name__ == "__main__":
    verify(Path(os.environ.get("PDBTHINK_TEST_ROOT", "/tests")),
           Path(os.environ.get("PDBTHINK_ANSWER", "/app/answer.txt")),
           Path(os.environ.get("PDBTHINK_REWARD_DIR", "/logs/verifier")))
